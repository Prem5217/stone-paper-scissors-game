package com.example.frontend_mentor_rock_paper_scissors

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
