import 'package:flutter/material.dart';
import 'package:frontend_mentor_rock_paper_scissors/app.dart';

void main() {
  runApp(const FrontendMentorRockPaperScissorsApp());
}
